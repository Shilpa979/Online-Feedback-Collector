from flask import Flask, render_template, request, redirect, url_for
import sqlite3
from datetime import datetime

app = Flask(__name__)

# Database connection
def get_db_connection():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    return conn

# Create table if not exists
conn = get_db_connection()
conn.execute('''
CREATE TABLE IF NOT EXISTS feedback (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    email TEXT,
    rating INTEGER,
    comments TEXT,
    date_submitted TEXT
)
''')
conn.commit()
conn.close()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/submit-feedback', methods=['POST'])
def submit_feedback():
    name = request.form['name']
    email = request.form['email']
    rating = request.form['rating']
    comments = request.form['comments']
    date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    conn = get_db_connection()
    conn.execute(
        "INSERT INTO feedback (name, email, rating, comments, date_submitted) VALUES (?, ?, ?, ?, ?)",
        (name, email, rating, comments, date)
    )
    conn.commit()
    conn.close()

    return redirect(url_for('index'))

@app.route('/admin-dashboard')
def admin_dashboard():
    conn = get_db_connection()
    feedbacks = conn.execute("SELECT * FROM feedback").fetchall()
    avg_rating = conn.execute("SELECT AVG(rating) FROM feedback").fetchone()[0]
    total = len(feedbacks)
    conn.close()

    return render_template(
        'admin.html',
        feedbacks=feedbacks,
        avg_rating=avg_rating,
        total=total
    )

if __name__ == '__main__':
    app.run(debug=True)
